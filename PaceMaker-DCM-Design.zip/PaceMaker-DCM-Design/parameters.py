import tkinter as tk
from tkinter import ttk
from tkinter import *


window = tk.Tk()
window.title('Parameters')
window.geometry('800x700')


window.tk.call("source", "forest-dark.tcl")
#window.tk.call("set_theme", "dark")
ttk.Style().theme_use('forest-dark')

def comboclick(event):

    if Pacing_modes.get() == 'AOO':
        ttk.Label(window, text="Lower Rate Limit :",
                  font=("Times New Roman", 10)).grid(column=0,
                                                     row=8, padx=10, pady=25)
        LRL = ttk.Spinbox(window, from_=0, to=20)
        LRL.grid(column=1, row=8, padx=10, pady=25)
        LRL.insert(0, "Select Value")

        ttk.Label(window, text="Upper Rate Limit :",
                  font=("Times New Roman", 10)).grid(column=0,
                                                     row=9, padx=10, pady=25)
        URL = ttk.Spinbox(window, from_=0, to=20)
        URL.grid(column=1, row=9, padx=10, pady=25)
        URL.insert(0, "Select Value")

        ttk.Label(window, text="Atrial Amplitude :",
                  font=("Times New Roman", 10)).grid(column=0,
                                                     row=10, padx=10, pady=25)
        AA = ttk.Spinbox(window, from_=0, to=20)
        AA.grid(column=1, row=10, padx=10, pady=25)
        AA.insert(0, "Select Value")

        ttk.Label(window, text="Atrial Pulse Width :",
                  font=("Times New Roman", 10)).grid(column=0,
                                                     row=11, padx=10, pady=25)

        APW = ttk.Spinbox(window, from_=0, to=20)
        APW.grid(column=1, row=11, padx=10, pady=25)
        APW.insert(0, "Select Value")

        ttk.Label(window, text="ARP :",
                  font=("Times New Roman", 10)).grid(column=2,
                                                     row=11, padx=10, pady=25)

        ARP = ttk.Spinbox(window, from_=0, to=20)
        ARP.grid(column=3, row=11, padx=10, pady=25)
        ARP.config(state=DISABLED)

        ttk.Label(window, text="Ventricular Amplitude :",
                  font=("Times New Roman", 10)).grid(column=2,
                                                     row=8, padx=10, pady=25)
        VA = ttk.Spinbox(window, from_=0, to=20)
        VA.grid(column=3, row=8, padx=10, pady=25)
        VA.config(state=DISABLED)

        VPW = ttk.Spinbox(window, from_=0, to=20)
        VPW.grid(column=3, row=9, padx=10, pady=25)
        VPW.config(state=DISABLED)
        ttk.Label(window, text="Ventricular Pulse Width  :",
                  font=("Times New Roman", 10)).grid(column=2,
                                                     row=9, padx=10, pady=25)

        ttk.Label(window, text="VRP:",
                  font=("Times New Roman", 10)).grid(column=2,
                                                     row=10, padx=10, pady=25)
        VRP = ttk.Spinbox(window, from_=0, to=20)
        VRP.grid(column=3, row=10, padx=10, pady=25)
        VRP.config(state=DISABLED)





    if Pacing_modes.get() == 'AAI':
        ttk.Label(window, text="Lower Rate Limit :",
                  font=("Times New Roman", 10)).grid(column=0,
                                                     row=8, padx=10, pady=25)
        LRL = ttk.Spinbox(window, from_=0, to=20)
        LRL.grid(column=1, row=8, padx=10, pady=25)
        LRL.insert(0, "Select Value")

        ttk.Label(window, text="Upper Rate Limit :",
                  font=("Times New Roman", 10)).grid(column=0,
                                                     row=9, padx=10, pady=25)
        URL = ttk.Spinbox(window, from_=0, to=20)
        URL.grid(column=1, row=9, padx=10, pady=25)
        URL.insert(0, "Select Value")

        ttk.Label(window, text="Atrial Amplitude :",
                  font=("Times New Roman", 10)).grid(column=0,
                                                     row=10, padx=10, pady=25)
        AA = ttk.Spinbox(window, from_=0, to=20)
        AA.grid(column=1, row=10, padx=10, pady=25)
        AA.insert(0, "Select Value")

        ttk.Label(window, text="Atrial Pulse Width :",
                  font=("Times New Roman", 10)).grid(column=0,
                                                     row=11, padx=10, pady=25)

        APW = ttk.Spinbox(window, from_=0, to=20)
        APW.grid(column=1, row=11, padx=10, pady=25)
        APW.insert(0, "Select Value")

        ttk.Label(window, text="ARP :",
                  font=("Times New Roman", 10)).grid(column=2,
                                                     row=11, padx=10, pady=25)

        ARP = ttk.Spinbox(window, from_=0, to=20)
        ARP.grid(column=3, row=11, padx=10, pady=25)
        ARP.insert(0, "Select Value")


        ttk.Label(window, text="Ventricular Amplitude :",
                  font=("Times New Roman", 10)).grid(column=2,
                                                     row=8, padx=10, pady=25)
        VA = ttk.Spinbox(window, from_=0, to=20)
        VA.grid(column=3, row=8, padx=10, pady=25)
        VA.config(state=DISABLED)

        VPW = ttk.Spinbox(window, from_=0, to=20)
        VPW.grid(column=3, row=9, padx=10, pady=25)
        VPW.config(state=DISABLED)
        ttk.Label(window, text="Ventricular Pulse Width  :",
                  font=("Times New Roman", 10)).grid(column=2,
                                                     row=9, padx=10, pady=25)

        ttk.Label(window, text="VRP:",
                  font=("Times New Roman", 10)).grid(column=2,
                                                     row=10, padx=10, pady=25)
        VRP = ttk.Spinbox(window, from_=0, to=20)
        VRP.grid(column=3, row=10, padx=10, pady=25)
        VRP.config(state=DISABLED)


    if Pacing_modes.get() == 'VOO':
        ttk.Label(window, text="Lower Rate Limit :",
                  font=("Times New Roman", 10)).grid(column=0,
                                                     row=8, padx=10, pady=25)
        LRL = ttk.Spinbox(window, from_=0, to=20)
        LRL.grid(column=1, row=8, padx=10, pady=25)
        LRL.insert(0, "Select Value")

        ttk.Label(window, text="Upper Rate Limit :",
                  font=("Times New Roman", 10)).grid(column=0,
                                                     row=9, padx=10, pady=25)
        URL = ttk.Spinbox(window, from_=0, to=20)
        URL.grid(column=1, row=9, padx=10, pady=25)
        URL.insert(0, "Select Value")

        ttk.Label(window, text="Atrial Amplitude :",
                  font=("Times New Roman", 10)).grid(column=0,
                                                     row=10, padx=10, pady=25)
        AA = ttk.Spinbox(window, from_=0, to=20)
        AA.grid(column=1, row=10, padx=10, pady=25)
        AA.config(state=DISABLED)

        ttk.Label(window, text="Atrial Pulse Width :",
                  font=("Times New Roman", 10)).grid(column=0,
                                                     row=11, padx=10, pady=25)

        APW = ttk.Spinbox(window, from_=0, to=20)
        APW.grid(column=1, row=11, padx=10, pady=25)
        APW.config(state=DISABLED)

        ttk.Label(window, text="ARP :",
                  font=("Times New Roman", 10)).grid(column=2,
                                                     row=11, padx=10, pady=25)

        ARP = ttk.Spinbox(window, from_=0, to=20)
        ARP.grid(column=3, row=11, padx=10, pady=25)
        ARP.config(state=DISABLED)

        ttk.Label(window, text="Ventricular Amplitude :",
                  font=("Times New Roman", 10)).grid(column=2,
                                                     row=8, padx=10, pady=25)
        VA = ttk.Spinbox(window, from_=0, to=20)
        VA.grid(column=3, row=8, padx=10, pady=25)
        VA.insert(0, "Select Value")

        VPW = ttk.Spinbox(window, from_=0, to=20)
        VPW.grid(column=3, row=9, padx=10, pady=25)
        VPW.insert(0, "Select Value")


        ttk.Label(window, text="Ventricular Pulse Width  :",
                  font=("Times New Roman", 10)).grid(column=2,
                                                     row=9, padx=10, pady=25)

        ttk.Label(window, text="VRP:",
                  font=("Times New Roman", 10)).grid(column=2,
                                                     row=10, padx=10, pady=25)
        VRP =ttk. Spinbox(window, from_=0, to=20)
        VRP.grid(column=3, row=10, padx=10, pady=25)
        VRP.config(state=DISABLED)

    if Pacing_modes.get() == 'VII':
        ttk.Label(window, text="Lower Rate Limit :",
                  font=("Times New Roman", 10)).grid(column=0,
                                                     row=8, padx=10, pady=25)
        LRL = ttk.Spinbox(window, from_=0, to=20)
        LRL.grid(column=1, row=8, padx=10, pady=25)
        LRL.insert(0, "Select Value")

        ttk.Label(window, text="Upper Rate Limit :",
                  font=("Times New Roman", 10)).grid(column=0,
                                                     row=9, padx=10, pady=25)
        URL = ttk.Spinbox(window, from_=0, to=20)
        URL.grid(column=1, row=9, padx=10, pady=25)
        URL.insert(0, "Select Value")

        ttk.Label(window, text="Atrial Amplitude :",
                  font=("Times New Roman", 10)).grid(column=0,
                                                     row=10, padx=10, pady=25)
        AA = ttk.Spinbox(window, from_=0, to=20)
        AA.grid(column=1, row=10, padx=10, pady=25)
        AA.config(state=DISABLED)

        ttk.Label(window, text="Atrial Pulse Width :",
                  font=("Times New Roman", 10)).grid(column=0,
                                                     row=11, padx=10, pady=25)

        APW = ttk.Spinbox(window, from_=0, to=20)
        APW.grid(column=1, row=11, padx=10, pady=25)
        APW.config(state=DISABLED)

        ttk.Label(window, text="ARP :",
                  font=("Times New Roman", 10)).grid(column=2,
                                                     row=11, padx=10, pady=25)

        ARP = ttk.Spinbox(window, from_=0, to=20)
        ARP.grid(column=3, row=11, padx=10, pady=25)

        ARP.config(text="Disabled",state=DISABLED)

        ttk.Label(window, text="Ventricular Amplitude :",
                  font=("Times New Roman", 10)).grid(column=2,
                                                     row=8, padx=10, pady=25)
        VA = ttk.Spinbox(window, from_=0, to=20)
        VA.grid(column=3, row=8, padx=10, pady=25)
        VA.insert(0, "Select Value")


        VPW = ttk.Spinbox(window, from_=0, to=20)
        VPW.grid(column=3, row=9, padx=10, pady=25)
        VPW.insert(0, "Select Value")

        ttk.Label(window, text="Ventricular Pulse Width  :",
                  font=("Times New Roman", 10)).grid(column=2,
                                                     row=9, padx=10, pady=25)

        ttk.Label(window, text="VRP:",
                  font=("Times New Roman", 10)).grid(column=2,
                                                     row=10, padx=10, pady=25)
        VRP = ttk.Spinbox(window, from_=0, to=20)
        VRP.grid(column=3, row=10, padx=10, pady=25)
        VRP.insert(0, "Select Value")



# label
ttk.Label(window, text="Select the Pacing Mode :",
          font=("Times New Roman", 12)).grid(column=1,row=5, padx=10, pady=25)


Pacing_list = [
    "AOO",
    "VOO",
    "AAI",
    "VII",
]

# Combobox creation
Pacing_modes = ttk.Combobox(window, value=Pacing_list)
Pacing_modes.current(0)
Pacing_modes.bind("<<ComboboxSelected>>", comboclick)
Pacing_modes.grid(column=2, row=5)
button = ttk.Button(window, text='Accent button', style='Accent.TButton')
















#APW = Spinbox(window, from_= 0, to = 20)
#APW.grid(column=1,row=10, padx=10, pady=25)


window.mainloop()