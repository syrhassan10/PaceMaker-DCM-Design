import tkinter as tk
from tkinter import ttk
from tkinter import *
# Creating tkinter window
window = tk.Tk()
window.title('Parameters')
window.geometry('800x700')

# label text for title
#ttk.Label(window, text="GFG Combobox Widget",
          #background='green', foreground="white",
          #font=("Times New Roman", 15)).grid(row=0, column=1)




def comboclick(event):
    if Pacing_modes.get() != ' ':
        myLabel = Label(window, text="testting aai").grid()
        ttk.Label(window, text="Lower Rate Limit :",
                  font=("Times New Roman", 10)).grid(column=0,
                                                     row=8, padx=10, pady=25)
        LRL = Spinbox(window, from_=0, to=20)
        LRL.grid(column=5, row=8, padx=10, pady=25)

        ttk.Label(window, text="Upper Rate Limit :",
                  font=("Times New Roman", 10)).grid(column=0,
                                                     row=9, padx=10, pady=25)
        URL = Spinbox(window, from_=0, to=20)
        URL.grid(column=1, row=9, padx=10, pady=25)

        ttk.Label(window, text="Atrial Amplitude :",
                  font=("Times New Roman", 10)).grid(column=0,
                                                     row=10, padx=10, pady=25)
        AA = Spinbox(window, from_=0, to=20)
        AA.grid(column=1, row=10, padx=10, pady=25)

        ttk.Label(window, text="Atrial Pulse Width :",
                  font=("Times New Roman", 10)).grid(column=0,
                                                     row=11, padx=10, pady=25)
        APW = Spinbox(window, from_=0, to=20)
        APW.grid(column=1, row=11, padx=10, pady=25)

        ttk.Label(window, text="ARP :",
                  font=("Times New Roman", 10)).grid(column=2,
                                                     row=11, padx=10, pady=25)

        ARP = Spinbox(window, from_=0, to=20)
        ARP.grid(column=3, row=11, padx=10, pady=25)

        global LRL.grid_forget()
        URL.grid_forget()
        AA.grid_forget()
        APW.grid_forget()
        ARP.grid_forget()

        if Pacing_modes.get() == 'AOO':
            myLabel = Label(window, text= "testting aoo").grid()
            LRL.grid()
            URL.grid_forget()
            AA.grid_forget()
            APW.grid_forget()
            ARP.grid_forget()





        if Pacing_modes.get() == 'AAI':
            myLabel = Label(window, text="testting aai").grid()
            LRL.grid_forget()
            URL.grid_forget()
            AA.grid_forget()
            APW.grid_forget()
            ARP.grid_forget()



        if Pacing_modes.get() == 'VOO':
            myLabel = Label(window, text= "testting voo").grid()
            LRL.grid_forget()
            URL.grid_forget()
            AA.grid_forget()
            APW.grid_forget()
            ARP.grid_forget()


        if Pacing_modes.get() == 'VII':
            myLabel = Label(window, text="testting vii").grid()
            LRL.grid_forget()
            URL.grid_forget()
            AA.grid_forget()
            APW.grid_forget()
            ARP.grid_forget()


# label
ttk.Label(window, text="Select the Pacing Mode :",
          font=("Times New Roman", 12)).grid(column=1,
                                             row=5, padx=10, pady=25)

Pacing_list = [
    "AOO",
    "VOO",
    "AAI",
    "VII",
]

Pacing_modes = ttk.Combobox(window, value=Pacing_list)
Pacing_modes.current(0)
Pacing_modes.bind("<<ComboboxSelected>>", comboclick)
Pacing_modes.grid(column=2, row=5)


window.mainloop()